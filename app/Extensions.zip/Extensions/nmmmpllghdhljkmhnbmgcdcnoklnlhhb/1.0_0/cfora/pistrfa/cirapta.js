let zubikacha_oster = (fruch) => {
    traona.toggleClass('blue-eyes-disabled', fruch);
    chrome.storage.local.set({"fruscrata_cataca": fruch ? 0 : 1}, null);
}

let zubikacha_nusta =$("#zubikacha_nusta");

let zubikacha_kostra = (caruch) => {
    let ambara_zi = '#2d2d2d';
    let omnima_si = 'white';
    let purina_ti = '#eaeaea';

    switch (caruch) {
        case 4:
            ambara_zi = purina_ti = '#06191f';
            omnima_si = 'white';
            break;
        case 2:
            purina_ti = '#06191f';
            ambara_zi = '#e3e3e3';
            omnima_si = 'black';
            break;
        case 1:
            omnima_si = 'black';
            ambara_zi = purina_ti = 'white';
            break;
        case 3:
            purina_ti = '#eaeaea';
            ambara_zi = '#2d2d2d';
            omnima_si = 'white';
            break;
        default:
            purina_ti = '#eaeaea';
            ambara_zi = '#2d2d2d';
            omnima_si = 'white';
    }
    $('.blue-eyes-ignore').css('color', omnima_si);
}

let zubikacha_fafa = $("#zubikacha_fafa");
let rustra_kustra = (fruch) => {
    traona.toggleClass('blue-eyes-blacklist', !fruch);
}
const fumania_limno = /[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9](?:\.[a-zA-Z]{2,})+(\/maps\/)?/;
let traona = $('body');

chrome.storage.local.get("fruscrata_cataca", function (luch) {
    zubikacha_oster(luch.fruscrata_cataca !== 1);
});
