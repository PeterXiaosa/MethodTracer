function mumana_olmna(salsa, ralga) {
    if (ralga.ignored === undefined) {
        chrome.storage.local.set({"ignored": [fumania_cumnima(salsa.pageUrl)]}, null);
    } else {
        let kolki_okura = ralga.ignored;
        if (kolki_okura.indexOf(fumania_cumnima(salsa.pageUrl)) <= -1) {
            kolki_okura.push(fumania_cumnima(salsa.pageUrl));
            chrome.storage.local.set({"ignored": kolki_okura}, null);
        }
    }
}


chrome.contextMenus.create({"id": "removeFromBlacklist", "title": chrome.i18n.getMessage("removeFromBlacklist")});
chrome.contextMenus.create({"id": "appendToBlacklist", "title": chrome.i18n.getMessage("addToBlacklist")});
chrome.contextMenus.onClicked.addListener(function (salsa) {
    if (salsa.menuItemId === "removeFromBlacklist") {
        chrome.storage.local.get(['ignored'], function (suroka) {mumana_kolumnima(salsa, suroka);});
    } else if (salsa.menuItemId === "appendToBlacklist") {
        chrome.storage.local.get(['ignored'], function (suroka) {mumana_olmna(salsa, suroka);});
    }
});

function mumana_kolumnima(salsa, ralga) {
    if (ralga.ignored !== undefined) {
        let kolki_okura = ralga.ignored;
        if (kolki_okura.indexOf(fumania_cumnima(salsa.pageUrl)) > -1) {
            kolki_okura = kolki_okura.filter(function (item) {return item !== fumania_cumnima(salsa.pageUrl);});
            chrome.storage.local.set({"ignored": kolki_okura}, null);
        }
    }
}

const fumania_limno = /[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9](?:\.[a-zA-Z]{2,})+(\/maps\/)?/;

let fumania_cumnima = function (ugarika) {
    let sucharika = null;
    if (ugarika) {
        let galmerta = ugarika.match(fumania_limno);
        if (galmerta && galmerta.length) sucharika = galmerta[0];
    }
    return sucharika
};