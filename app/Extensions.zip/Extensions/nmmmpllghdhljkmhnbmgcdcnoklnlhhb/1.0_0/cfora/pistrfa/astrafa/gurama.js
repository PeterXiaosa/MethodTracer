zubikacha_fafa.on("click", function () {
    chrome.storage.local.get("fruscrata_cataca", function (kubiera) {
        if (kubiera.fruscrata_cataca === 1) {
            zubikacha_oster(true);
            chrome.storage.local.get(['ignored'], function (silogarta) {
                chrome.tabs.query({active: true, currentWindow: true}, function (burigarta) {
                    if (silogarta.ignored === undefined) {
                        zubikacha_kostra(2)
                    } else {
                        zubikacha_kostra(silogarta.ignored.indexOf(fumania_cumnima(burigarta[0].url)) > -1 ? 4 : 2);
                    }
                });
            });

        } else {
            zubikacha_oster(false);
            chrome.storage.local.get(['ignored'], function (silogarta) {
                chrome.tabs.query({active: true, currentWindow: true}, function (burigarta) {
                    if (silogarta.ignored === undefined) {
                        zubikacha_kostra(3)
                    } else {
                        zubikacha_kostra(silogarta.ignored.indexOf(fumania_cumnima(burigarta[0].url)) > -1 ? 1 : 3);
                    }
                });
            });
        }
    });
});

let fumania_cumnima = function (dimberarta) {
    let sofa = null;
    if (dimberarta) {
        let pirtka = dimberarta.match(fumania_limno);
        if (pirtka && pirtka.length) sofa = pirtka[0];
    }
    return sofa
};

zubikacha_nusta.on("click", function () {
    chrome.storage.local.get(['ignored'], function (silogarta) {
        chrome.tabs.query({active: true, currentWindow: true}, function (burigarta) {
            if (silogarta.ignored === undefined) {
                chrome.storage.local.set({"ignored": [fumania_cumnima(burigarta[0].url)]}, null);
                rustra_kustra(false);
                chrome.storage.local.get("fruscrata_cataca", function (kubiera) {zubikacha_kostra(kubiera.fruscrata_cataca === 1 ? 1 : 4);});
            } else {
                let sferararta = silogarta.ignored;
                if (sferararta.indexOf(fumania_cumnima(burigarta[0].url)) > -1) {
                    sferararta = sferararta.filter(function (punchuia) {return punchuia !== fumania_cumnima(burigarta[0].url);});
                    chrome.storage.local.set({"ignored": sferararta}, null);
                    rustra_kustra(true);
                    chrome.storage.local.get("fruscrata_cataca", function (kubiera) {zubikacha_kostra(kubiera.fruscrata_cataca === 1 ? 3 : 2);});
                } else {
                    sferararta.push(fumania_cumnima(burigarta[0].url));
                    chrome.storage.local.set({"ignored": sferararta}, null);
                    rustra_kustra(false);
                    chrome.storage.local.get("fruscrata_cataca", function (kubiera) {zubikacha_kostra(kubiera.fruscrata_cataca === 1 ? 1 : 4);});
                }
            }
        });
    });
});

chrome.storage.local.get(['ignored'], function (silogarta) {
    chrome.tabs.query({active: true, currentWindow: true}, function (burigarta) {
        if (silogarta.ignored === undefined) {
            rustra_kustra(true);
            chrome.storage.local.get("fruscrata_cataca", function (kubiera) {zubikacha_kostra(kubiera.fruscrata_cataca === 1 ? 3 : 2);});
        } else {
            let sferararta = silogarta.ignored;
            if (sferararta.indexOf(fumania_cumnima(burigarta[0].url)) > -1) {
                rustra_kustra(false);
                chrome.storage.local.get("fruscrata_cataca", function (kubiera) {zubikacha_kostra(kubiera.fruscrata_cataca === 1 ? 1 : 4);});
            } else {
                rustra_kustra(true);
                chrome.storage.local.get("fruscrata_cataca", function (kubiera) {zubikacha_kostra(kubiera.fruscrata_cataca === 1 ? 3 : 2);});
            }
        }
    });
});
