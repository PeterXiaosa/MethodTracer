if (!$("#blue-eyes-styles").length) {
    let sderma_ver = [window.location.host, document.location.href];
    let guichka = {
        "instagram.com": "inst",
        "mail.google.com": "mail",
        "medium.com": "medi",
        "messenger.com": "mess",
        "notifications.google.com": "noti",
        "quora.com": "quor",
        "reddit.com": "redd",
        "sites.google.": "site",
        "stackoverflow.com": "stac",
        "tasks.google.com/embed/": "task",
        "thesaurus.com": "thes",
        "translate.google": "tran",
        "tumblr.": "tumb",
        "twitch.tv": "twic",
        "twitter.com": "twit",
        "udemy.com": "udem",
        "web.whatsapp.com": "web.",
        "wikipedia.org": "wiki",
        "yahoo.": "yaho",
        "youtube.": "yout"
    };
    let germa_gronuia = {
        "amaz": "parama",
        "bing": "kurama",
        "cale": "farama",
        "clas": "darama",
        "cont": "barama",
        "cour": "fiama",
        "docs": "ziama",
        "docp": "zuama",
        "driv": "fofo",
        "drop": "gogog",
        "duck": "sisidsa",
        "ebay": "uio",
        "ever": "diafa",
        "gith": "sukilo",
        "goog": "lala",
        "goom": "pokila",
        "inbo": "erererer",
        "inst": "wedro",
        "mail": "kjiko",
        "medi": "lastokiara",
        "mess": "ftora",
        "noti": "zaxasa",
        "quor": "zizizizzi",
        "redd": "didididdi",
        "site": "puerarata",
        "stac": "twqasda",
        "task": "bvino",
        "thes": "zaqadafaga",
        "tran": "pkil",
        "tumb": "ggttrr",
        "twic": "hhllkk",
        "twit": "parasha",
        "udem": "kashsa",
        "web.": "pkkklilo",
        "wiki": "hgerata",
        "yaho": "hierata",
        "yout": "dadafa"
    };
    let efo_rasta = {
        "amazon.": "amaz",
        "bing.com": "bing",
        "calendar.google": "cale",
        "classroom.google.com": "clas",
        "contacts.google.com/": "cont",
        "coursera.org": "cour",
        "docs.google.": "docs",
        "docs.google.com/picker": "docp",
        "drive.google.": "driv",
        "dropbox.": "drop",
        "duckduckgo.com": "duck",
        "ebay.com": "ebay",
        "evernote.com": "ever",
        "github.com": "gith",
        "google.com": "goog",
        "google.com/maps/": "goom",
        "inbox.google.": "inbo"
    };
    let zonka_vonka = false;
    function aligatoria_uriera() {
        for (let polkaxa_zavera = 0; polkaxa_zavera < sderma_ver.length; polkaxa_zavera++) {
            let dumbitoa = sderma_ver[polkaxa_zavera];
            let sulfitara_mara = fumania_cumnima(dumbitoa) + '';
            if (dumbitoa.indexOf("/chrome/newtab") === -1) {
                for (let eco_coedara in efo_rasta) {
                    if (sulfitara_mara.indexOf(eco_coedara) > -1) {
                        zonka_vonka = true;
                        afinaha_lupa(ferna_aferna('cfora/' + germa_gronuia[efo_rasta[eco_coedara]]));
                        break;
                    }
                }
                if (!zonka_vonka) {
                    for (let eco_coedara in guichka) {
                        if (sulfitara_mara.indexOf(eco_coedara) > -1) {
                            afinaha_lupa(ferna_aferna('cfora/pistrfa/astrafa/' + germa_gronuia[guichka[eco_coedara]]));
                            break;
                        }
                    }
                }
                new fufelaona();
                break;
            }
        }
    }
    let paramaratara = document.documentElement || document.head || document.querySelector("head");
    chrome.storage.local.get("fruscrata_cataca", function (delieyngria) {
        if (delieyngria.fruscrata_cataca === 1) {
            chrome.storage.local.get(['ignored'], function (pelo_pal) {
                if (pelo_pal.ignored !== undefined) {
                    let sigmunda = pelo_pal.ignored;
                    for (let polkaxa_zavera = 0; polkaxa_zavera < sderma_ver.length; polkaxa_zavera++) {
                        const dumbitoa = sderma_ver[polkaxa_zavera];
                        let sulfitara_mara = fumania_cumnima(dumbitoa) + '';
                        if (sigmunda.indexOf(sulfitara_mara) <= -1) {
                            aligatoria_uriera();
                            paramaratara && paramaratara.appendChild(pweqasa[0]);
                            break;
                        }
                    }
                } else {
                    aligatoria_uriera();
                    paramaratara && paramaratara.appendChild(pweqasa[0])
                }
            });
        }
    });
    function afinaha_lupa(seda_strofa) {
        fetch(chrome.runtime.getURL(seda_strofa))
            .then(function (fgin) {
                return fgin.text();
            })
            .then(function (fgin) {
                pweqasa.text(fgin);
            })
    }

    let pweqasa = $('<style id="blue-eyes-custom-domain" type="text/css"></style>');

    function ferna_aferna(candaga) {
        return '/' + candaga + '.css';
    }

    $('body').append('<div id="blue-eyes-styles"></div>');

}

$(function ($) {
    chrome.storage.local.get("fruscrata_cataca", function (delieyngria) {
        if (delieyngria.fruscrata_cataca === 1) {
            chrome.storage.local.get(['ignored'], function (pelo_pal) {
                if (pelo_pal.ignored !== undefined) {
                    let sigmunda = pelo_pal.ignored;
                    if (sigmunda.indexOf("facebook.com") <= -1) {
                        if (!$('body').hasClass("__fb-dark-mode")) {
                            $('body').addClass("__fb-dark-mode");
                            return;
                        }
                    }
                } else {
                    if (!$('body').hasClass("__fb-dark-mode")) {
                        $('body').addClass("__fb-dark-mode");
                        return;
                    }
                }
            });
        }
    })
});

let fumania_cumnima = function (momo) {
    let edsa_wista = null;
    if (momo) {
        let periera = momo.match(fumania_limno);
        if (periera && periera.length) edsa_wista = periera[0];
    }

    return edsa_wista
};

const fumania_limno = /[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9](?:\.[a-zA-Z]{2,})+(\/maps\/)?/;
