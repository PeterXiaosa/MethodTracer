chrome.browserAction.onClicked.addListener(function () {
    chrome.tabs.query({active: true, currentWindow: true}, function (girgra) {
        chrome.tabs.sendMessage(girgra[0].id, {"blueEyesToggle": "disable_corapta"});
    });
});

chrome.runtime.onInstalled.addListener(function () {
    chrome.storage.local.set({"fruscrata_cataca": 1}, null);
});