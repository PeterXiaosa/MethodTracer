class fufelaona {
    zorina_urina(cici, cucu) {
        const caca = new Date()
        return caca.getHours() >= cici || caca.getHours() < cucu;
    }

    seluvha_okila() {
        if (!$('blue-eyes-styles').length) {
            let gora = $('<div id="blue-eyes-styles"></div>');
            gora.attr('style', this.ferbula);
            $('body').append(gora);
        }
    }

    findora() {
        let ybunia = this.zorina_urina('22', '7');
        if (this.perlioma.curniola !== ybunia) {
            this.perlioma.curniola = ybunia;
            this.crobula();
        }
    }

    constructor() {
        this.perlioma = {
            curniola: true,
            safarola: 15,
            id: 'blue-eyes-styles',
            efera: '#fac563'
        };
        this.vuldora();
        this.cordora();
        this.sreputa();
    }

    get ferbula() {
        return `background: ${this.perlioma.efera} !important; opacity: ${(this.perlioma.safarola * .008 + .2).toFixed(3)}; display: ${this.perlioma.curniola ? 'block' : 'none'}; mix-blend-mode: multiply; transition: opacity 0.1s ease 0s; border-radius: 0; margin: 0; padding: 0; top: -10%; right: -10%; width: 120%; height: 120%; position: fixed; pointer-events: none; z-index: 2147483647;`;
    }

    vuldora() {
        chrome.storage.local.get(this.perlioma, erna => {
            this.perlioma = erna;
            this.seluvha_okila();
            this.findora();
        });
    }


    sreputa() {
        chrome.runtime.onMessage.addListener(debunia => {
            if (debunia.blueEyesToggle === "disable_corapta") {
                this.perlioma.curniola = false;
                this.crobula();
            }
        });
    }

    crobula() {
        chrome.storage.local.set(this.perlioma);
    }

    cordora() {
        chrome.storage.onChanged.addListener(cirtra => {
            for (let siofgrea in cirtra) {
                this.perlioma[siofgrea] = cirtra[siofgrea].newValue;
            }
            $(this.id).attr('style', (this.ferbula || ''));
        });
    }
}
